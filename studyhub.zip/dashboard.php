<?php
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

include("db.php");

// Get current user's ID
$email = $_SESSION["email"];
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$userId = $user['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>StudyHub Dashboard</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(to right, #8360c3, #2ebf91);
      margin: 0;
      padding: 20px;
      color: white;
    }

    .dashboard-container {
      max-width: 900px;
      margin: auto;
    }

    h1 {
      text-align: center;
    }

    .note-box {
      background: rgba(0, 0, 0, 0.3);
      padding: 20px;
      margin: 20px 0;
      border-radius: 10px;
    }

    .note-box h3 {
      margin: 0;
      color: #ffe082;
    }

    .note-box a {
      color: #ffd700;
      text-decoration: underline;
    }

    .like-btn {
      margin-top: 10px;
    }

    .like-count {
      margin-top: 5px;
      color: #ffdf00;
    }

    .top-links {
      text-align: center;
      margin-top: 20px;
      margin-bottom: 20px;
    }

    .top-links a,
    .upload-btn {
      background: #4caf50;
      color: white;
      padding: 10px 20px;
      font-size: 14px;
      border-radius: 6px;
      text-decoration: none;
      margin: 0 10px;
      display: inline-block;
    }

    .upload-btn:hover {
      background-color: #388e3c;
    }

    .logout-btn {
      background: #ff5e57;
      border: none;
      color: white;
      padding: 10px 20px;
      font-size: 14px;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
    }

    .logout-btn:hover {
      background: #e84141;
    }

    .share-section {
      margin-top: 10px;
    }

    .share-section input[type="text"] {
      width: 60%;
      padding: 5px;
      border-radius: 4px;
      border: none;
    }

    .share-section button,
    .share-section a {
      padding: 6px 10px;
      background: #4caf50;
      color: white;
      border: none;
      border-radius: 5px;
      text-decoration: none;
      margin-left: 5px;
      font-size: 14px;
    }

    .share-section button:hover,
    .share-section a:hover {
      background: #3e8e41;
    }

    .delete-btn {
      background: #f44336;
      color: white;
      border: none;
      padding: 6px 10px;
      border-radius: 5px;
      margin-top: 8px;
      cursor: pointer;
    }

    .delete-btn:hover {
      background: #c62828;
    }
  </style>
</head>
<body>

<div class="dashboard-container">
  <h1>📚 StudyHub Dashboard</h1>
  <p>Welcome, <strong><?= htmlspecialchars($_SESSION["email"]) ?></strong></p>

  <div class="top-links">
    <a class="upload-btn" href="upload.php">➕ Upload New Notes</a>
    <a class="logout-btn" href="logout.php">Logout</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
    <p style="color:limegreen; text-align:center;">✅ Note deleted successfully!</p>
  <?php endif; ?>

  <?php
  $sql = "SELECT m.*, u.email AS uploader_email 
          FROM materials m 
          JOIN users u ON m.uploaded_by = u.id 
          ORDER BY m.uploaded_at DESC";

  $result = $conn->query($sql);

  if ($result && $result->num_rows > 0):
    while ($row = $result->fetch_assoc()):
        $materialId = $row['id'];
        $noteUrl = "http://localhost/Studyhub/" . $row['filename'];

        // Count likes
        $likeStmt = $conn->prepare("SELECT COUNT(*) as total FROM note_likes WHERE material_id = ?");
        $likeStmt->bind_param("i", $materialId);
        $likeStmt->execute();
        $likeResult = $likeStmt->get_result();
        $likeCount = $likeResult->fetch_assoc()['total'] ?? 0;

        // Check if user already liked
        $checkStmt = $conn->prepare("SELECT 1 FROM note_likes WHERE material_id = ? AND user_id = ?");
        $checkStmt->bind_param("ii", $materialId, $userId);
        $checkStmt->execute();
        $alreadyLiked = $checkStmt->get_result()->num_rows > 0;
  ?>

    <div class="note-box">
      <h3><?= htmlspecialchars($row['title']) ?></h3>
      <p>📚 Subject: <?= htmlspecialchars($row['subject']) ?> | 🎓 Semester: <?= htmlspecialchars($row['semester']) ?></p>
      <p>👤 Uploaded by: <?= htmlspecialchars($row['uploader_email']) ?> | 📅 <?= $row['uploaded_at'] ?></p>
      <a href="<?= htmlspecialchars($row['filename']) ?>" target="_blank">📄 View/Download Note</a>

      <?php if (!$alreadyLiked): ?>
        <form action="like_note.php" method="POST" class="like-btn">
          <input type="hidden" name="material_id" value="<?= $materialId ?>">
          <button type="submit">👍 Like</button>
        </form>
      <?php else: ?>
        <p class="like-count">❤️ You liked this</p>
      <?php endif; ?>

      <p class="like-count">👍 Total Likes: <?= $likeCount ?></p>

      <!-- Share Section -->
      <div class="share-section">
        <input type="text" id="shareLink<?= $materialId ?>" value="<?= $noteUrl ?>" readonly>
        <button onclick="copyToClipboard(<?= $materialId ?>)">📋 Copy</button>
        <a href="https://wa.me/?text=Check out this note: <?= urlencode($noteUrl) ?>" target="_blank">📤 WhatsApp</a>
      </div>

      <!-- Delete Button -->
      <?php if ($row['uploaded_by'] == $userId): ?>
        <form action="delete_note.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this note?');">
          <input type="hidden" name="note_id" value="<?= $materialId ?>">
          <button type="submit" class="delete-btn">🗑️ Delete</button>
        </form>
      <?php endif; ?>
    </div>

  <?php
    endwhile;
  else:
    echo "<p>No notes uploaded yet.</p>";
  endif;
  ?>
</div>

<script>
function copyToClipboard(id) {
  const copyText = document.getElementById("shareLink" + id);
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  document.execCommand("copy");
  alert("✅ Link copied: " + copyText.value);
}
</script>

</body>
</html>
