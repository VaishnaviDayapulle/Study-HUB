<?php
include('db.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Basic SQL injection protection (for demo only; use prepared statements for production)
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $_SESSION["email"] = $email;

        // Debug message to confirm login before redirect
        echo "<script>console.log('Login successful');</script>";

        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid login credentials.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>StudyHub Login</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #74ebd5, #9face6);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .login-box {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      width: 350px;
    }

    .login-box h2 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    .login-box label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #444;
    }

    .login-box input[type="email"],
    .login-box input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #bbb;
      border-radius: 5px;
      outline: none;
      font-size: 14px;
    }

    .login-box input:focus {
      border-color: #4a90e2;
    }

    .login-box input[type="submit"] {
      width: 100%;
      padding: 12px;
      background: #4a90e2;
      border: none;
      color: white;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .login-box input[type="submit"]:hover {
      background: #357ABD;
    }

    .login-box .register-link {
      margin-top: 15px;
      text-align: center;
      font-size: 0.9em;
    }

    .login-box .register-link a {
      color: #4a90e2;
      text-decoration: none;
    }

    .login-box .register-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <h2> StudyHub Login</h2>

    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <input type="email" name="email" placeholder="Email" required /><br><br>
      <input type="password" name="password" placeholder="Password" required /><br><br>
      <input type="submit" value="Login" />
    </form>

    <div class="register-link">
      Don't have an account? <a href="register.php">Register here</a>
    </div>
  </div>
</body>
</html>
