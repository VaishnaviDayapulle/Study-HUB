<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include("db.php");

    $title = trim($_POST["title"] ?? '');
    $subject = trim($_POST["subject"] ?? '');
    $semester = trim($_POST["semester"] ?? '');
    $email = $_SESSION["email"];
    $file = $_FILES["note"] ?? null;

    // ✅ Fetch user ID from email
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $message = " User not found.";
    } else {
        $user = $result->fetch_assoc();
        $uploaded_by = $user["id"];  // Use user ID, not email

        // ✅ Continue with file processing
        $allowedTypes = ['pdf', 'docx', 'txt'];
        $maxSize = 50 * 1024 * 1024; // 50MB
        $targetDir = "uploads/";

        if (!$file || empty($file["name"])) {
            $message = " Please select a file.";
        } else {
            $filename = basename($file["name"]);
            $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $targetFile = $targetDir . uniqid() . "_" . $filename;

            if (!in_array($fileExtension, $allowedTypes)) {
                $message = " Only PDF, DOCX, or TXT files allowed.";
            } elseif ($file["size"] > $maxSize) {
                $message = " File too large. Max 50MB.";
            } elseif ($file["error"] !== 0) {
                $message = " Upload error: " . $file["error"];
            } else {
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }

                if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                    $sql = "INSERT INTO materials (title, filename, uploaded_by, subject, semester)
                            VALUES (?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssiss", $title, $targetFile, $uploaded_by, $subject, $semester);

                    if ($stmt->execute()) {
                        $message = "✅ Note uploaded successfully!";
                        $success = true;
                    } else {
                        $message = " Database error: " . $stmt->error;
                    }
                } else {
                    $message = " Failed to move uploaded file.";
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload Material | StudyHub</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f0f2f5;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .upload-box {
      background: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
      width: 400px;
    }

    .upload-box h2 {
      text-align: center;
      margin-bottom: 25px;
    }

    .upload-box input[type="text"],
    .upload-box input[type="file"] {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .upload-box input[type="submit"] {
      width: 100%;
      background: #4CAF50;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
      margin-top: 10px;
    }

    .upload-box input[type="submit"]:hover {
      background-color: #43a047;
    }

    .message {
      padding: 12px;
      margin-top: 15px;
      border-radius: 5px;
      text-align: center;
      font-weight: bold;
    }

    .success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    a {
      display: block;
      text-align: center;
      margin-top: 20px;
      color: #007bff;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="upload-box">
    <h2>📤 Upload Material</h2>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
      <input type="text" name="title" placeholder="Title" required>
      <input type="text" name="subject" placeholder="Subject" required>
      <input type="text" name="semester" placeholder="Semester (e.g. 3rd)" required>
      <input type="file" name="note" accept=".pdf,.docx,.txt" required>
      <input type="submit" value="Upload Note">
    </form>

    <?php if (!empty($message)): ?>
      <div class="message <?= $success ? 'success' : 'error' ?>">
        <?= $message ?>
      </div>
    <?php endif; ?>

    <a href="dashboard.php">⬅️ Back to Dashboard</a>
  </div>

</body>
</html>

