<?php
include('db.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $role = $_POST["role"];

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $role);

    if ($stmt->execute()) {
        echo "Registration successful. <a href='login.php'>Login here</a>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>StudyHub Register</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #74ebd5, #9face6);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .register-box {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      width: 380px;
    }

    .register-box h2 {
      text-align: center;
      color: #444;
      margin-bottom: 25px;
    }

    .register-box label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #333;
    }

    .register-box input,
    .register-box select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
      outline: none;
    }

    .register-box input:focus,
    .register-box select:focus {
      border-color: #ff7043;
    }

    .register-box button {
      width: 100%;
      padding: 12px;
      background: #6083ecff;
      border: none;
      color: white;
      font-size: 16px;
      font-weight: bold;
      border-radius: 5px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .register-box button:hover {
      background: #e64a19;
    }

    .login-link {
      margin-top: 15px;
      text-align: center;
      font-size: 0.9em;
    }

    .login-link a {
      color: #ff7043;
      text-decoration: none;
    }

    .login-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="register-box">
    <h2> Register for StudyHub</h2>
    <form action="register.php" method="post">
      <label for="name">Name</label>
      <input name="name" id="name" required>

      <label for="email">Email</label>
      <input name="email" id="email" required>

      <label for="password">Password</label>
      <input type="password" name="password" id="password" required>

      <label for="role">Role</label>
      <select name="role" id="role">
        <option value="student">Student</option>
        <option value="lecturer">Lecturer</option>
      </select>

      <button type="submit">Register</button>
    </form>

    <div class="login-link">
      Already have an account? <a href="login.html">Login here</a>
    </div>
  </div>
</body>
</html>

