<?php
session_start();
include("db.php");

if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["note_id"])) {
    $noteId = $_POST["note_id"];

    // Get the user ID of the current user
    $email = $_SESSION["email"];
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $userId = $user['id'];

    // Fetch note details to delete the file
    $stmt = $conn->prepare("SELECT filename FROM materials WHERE id = ? AND uploaded_by = ?");
    $stmt->bind_param("ii", $noteId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($note = $result->fetch_assoc()) {
        $filePath = $note['filename'];

        // Delete file from folder
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete from database
        $deleteStmt = $conn->prepare("DELETE FROM materials WHERE id = ? AND uploaded_by = ?");
        $deleteStmt->bind_param("ii", $noteId, $userId);
        if ($deleteStmt->execute()) {
            header("Location: dashboard.php?msg=deleted");
            exit();
        } else {
            echo "❌ Error deleting from database.";
        }
    } else {
        echo "❌ Note not found or unauthorized.";
    }
} else {
    echo "❌ Invalid request.";
}
?>
