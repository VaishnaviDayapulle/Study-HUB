<?php
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["material_id"])) {
    $material_id = $_POST["material_id"];

    // Get current user ID
    $email = $_SESSION["email"];
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $user_id = $user['id'];

    // Insert like only if it doesn't already exist
    $check = $conn->prepare("SELECT * FROM note_likes WHERE user_id = ? AND material_id = ?");
    $check->bind_param("ii", $user_id, $material_id);
    $check->execute();
    $exists = $check->get_result();

    if ($exists->num_rows === 0) {
        $like = $conn->prepare("INSERT INTO note_likes (user_id, material_id) VALUES (?, ?)");
        $like->bind_param("ii", $user_id, $material_id);
        $like->execute();
    }

    // Redirect back to dashboard
    header("Location: dashboard.php");
    exit();
} else {
    echo "Invalid request.";
}
?>
